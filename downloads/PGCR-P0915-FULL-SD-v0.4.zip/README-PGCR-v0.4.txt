PGCR v0.4 - CarPlay Source Probe
=================================
Read-only diagnostic build for MHI2Q_CN_AUG22_P0915.

1. Update Toolbox.
2. Green Menu -> PGCR Display Lab -> Install/Update PGCR v0.4.
3. Disconnect CarPlay -> run "1. Probe BASELINE".
4. Connect CarPlay and show Amap -> run "2. Probe CARPLAY".
5. Run "3. Compare probes - SHOW RESULT".
6. Photograph the result screen.
7. Full raw results are also copied to SD/PGCR-Probe/.

Probe does not call Screen setters and does not change Cluster contexts.
v0.3 renderer remains available as fallback.
