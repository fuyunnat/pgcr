PGCR v0.4 COMPLETE SD - CarPlay Source Probe
=================================================
Complete upstream V2.2 SD base + PGCR v0.4 read-only source probe.
Extract all contents directly to an empty FAT32 SD root.

Test order:
1. Red Engineering Menu -> update Toolbox.
2. Green Menu -> PGCR Display Lab -> Install/Update PGCR v0.4.
3. Disconnect/exit CarPlay -> 1. Probe BASELINE.
4. Connect CarPlay, keep Amap visible -> 2. Probe CARPLAY.
5. 3. Compare probes - SHOW RESULT.
6. Photograph the result or read SD:/PGCR-Probe/compare.txt.

Probe is read-only: no Screen setters and no Cluster context rerouting.
