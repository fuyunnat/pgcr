#!/bin/sh
exec /bin/sh /eso/hmi/engdefs/scripts/mqb/pgcr_set_viewport.sh cover 1.20 0.00 0.25
