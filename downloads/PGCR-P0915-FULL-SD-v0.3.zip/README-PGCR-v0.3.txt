PGCR v0.3 - Amap asymmetric Crop / Cover / Pan

1. Merge this ZIP into the root of your existing working V2.2 SD card.
2. Red Engineering Menu -> Software Update -> update Toolbox as before.
3. Reboot MMI.
4. Green Menu -> mqbcoding -> customization -> PGCR Display Lab.
5. Install/Update PGCR v0.3.
6. Reboot MMI.
7. PGCR Display Lab -> Start PGCR WideMap.
8. Start with WIDE 1.00x, then test Amap trim-left 6% / 8% / 10% / 12%.
9. Return to original at any time with "Return to upstream MMI Mirror".
